//
//  ViewController.swift
//  MovieApp
//
//  Created by Aruzhan Taskinbayeva on 12.02.2021.
//

import UIKit
import Kingfisher
import Alamofire

class MovieNewsViewController: UIViewController {

    @IBOutlet weak var tableView: UITableView!
    
    private var currentPage: Int = 1
    
    var movies: [MovieNewsEntity.Movie] = [] {
        didSet {
            tableView.reloadData()
        }
    }
    
    public let MOVIE_NEWS_URL = "https://api.themoviedb.org/3/trending/movie/week"
    public let API_KEY = "187c966d5c10e5058a922be1f19aeab3"
    //https://api.themoviedb.org/3/movie/id
//    https://api.themoviedb.org/3/movie/581389?api_key=187c966d5c10e5058a922be1f19aeab3&language=en-US

    //let url = Constants.host + "?q=\(Constants.city)&appid=\(Constants.apiKey)&units=metric"
    
    public let MOVIE_DESC_URL = "https://api.themoviedb.org/3/movie/581389?api_key=187c966d5c10e5058a922be1f19aeab3&language=en-US"
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        title = "News"
        
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(UINib(nibName: MovieCell.identifier, bundle: Bundle(for: MovieCell.self)), forCellReuseIdentifier: MovieCell.identifier)
        tableView.contentInset = UIEdgeInsets(top: 0, left: 0, bottom: 0, right: 0)
        
        getTrendingMovies()
    }

}

//MARK:- Internal Movie News Methods
extension MovieNewsViewController {
    
    func getTrendingMovies(page: Int? = nil) {
        var params: [String: Any] = ["api_key": API_KEY]
        if let page = page {
            params["page"] = page
        }
        
        AF.request(MOVIE_NEWS_URL, method: .get, parameters: params).responseJSON { (response) in
            switch response.result {
            case .success(_):
//                print(response)
                do {
                    if let data = response.data {
                        let json = try JSONDecoder().decode(MovieNewsEntity.self, from: data)
                        self.movies += json.results
//                        print(json.results.first?.originalTitle)
                    }
                } catch {
                    print(error)
                }
            case .failure(let error):
                print(error)
            }
        }
    }
}


extension MovieNewsViewController{
    
}

//MARK:- UITableViewDelegate
extension MovieNewsViewController: UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        if let moviedetailsVC = storyboard?.instantiateViewController(identifier: "MovieDetailsViewController") as? MovieDetailsViewController {
           
            let url = URL(string: "https://image.tmdb.org/t/p/w300\(movies[indexPath.row].posterPath ?? "")")
            
            
            moviedetailsVC.movieid = movies[indexPath.row].id
            
            moviedetailsVC.movieName = movies[indexPath.row].originalTitle
            moviedetailsVC.movieDescription = movies[indexPath.row].posterPath ?? "NIL"
            moviedetailsVC.relaseDate = movies[indexPath.row].releaseDate
            moviedetailsVC.posterImage = url
            
            navigationController?.pushViewController(moviedetailsVC, animated: true)
        }
    }
    
    public func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let currentOffset = scrollView.contentOffset.y
        let maximumOffset = scrollView.contentSize.height - scrollView.frame.size.height
        let deltaOffset = maximumOffset - currentOffset
        
        if deltaOffset <= 10 && scrollView.contentOffset.y > 200 {
            currentPage += 1
            getTrendingMovies(page: currentPage)
        }
    }
}

//MARK:- UITableViewDataSource
extension MovieNewsViewController: UITableViewDataSource {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return movies.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: MovieCell.identifier, for: indexPath) as! MovieCell
        let url = URL(string: "https://image.tmdb.org/t/p/w300\(movies[indexPath.row].posterPath ?? "")")
        cell.posterImageView.kf.setImage(with: url)
        cell.movieNameLabel.text = movies[indexPath.row].originalTitle
        cell.relaseDateLabel.text = movies[indexPath.row].releaseDate
        cell.ratingLabel.text = String(movies[indexPath.row].voteAverage)
        return cell
    }
}
