//
//  MovieDetailsViewController.swift
//  MovieApp
//
//  Created by Aruzhan Taskinbayeva on 12.02.2021.
//

import UIKit

class MovieDetailsViewController: UIViewController {
    
    @IBOutlet weak var posterImageVIew: UIImageView!
    @IBOutlet weak var movieNameLabel: UILabel!
    @IBOutlet weak var relaseDateLabel: UILabel!
    @IBOutlet weak var movieDescriptionLabel: UILabel!
    
    var movieid: Int = 0
    var posterImage : URL?
    var movieName = ""
    var relaseDate = ""
    var movieDescription = ""
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        posterImageVIew.kf.setImage(with: posterImage)
        movieNameLabel.text = movieName
        relaseDateLabel.text = relaseDate
        movieDescriptionLabel.text = movieDescription
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
